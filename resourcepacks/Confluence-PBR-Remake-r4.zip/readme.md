这是一个为汇流来世制作的PBR材质，你可以随意把它加入到你的整合包里或者供自己游玩，但是请你在分发的时候顺带发一下材质包的modrinth链接
如果有问题可以联系我的QQ：1121887114

This is a PBR texture pack made for Confluence:Otherworld mod.
When you want to distribute this pack，please leave this pack's modrinth link.
You can contact me through this email:1121887114@qq.com